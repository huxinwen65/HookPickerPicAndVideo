//
//  HookPickerPicAndVideo.h
//  HookPickerPicAndVideo
//
//  Created by huxinwen65 on 2018/3/2.
//  Copyright © 2018年 huxinwen65. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for HookPickerPicAndVideo.
FOUNDATION_EXPORT double HookPickerPicAndVideoVersionNumber;

//! Project version string for HookPickerPicAndVideo.
FOUNDATION_EXPORT const unsigned char HookPickerPicAndVideoVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <HookPickerPicAndVideo/PublicHeader.h>
#import <HookPickerPicAndVideo/RedPickerBaseViewController.h>

