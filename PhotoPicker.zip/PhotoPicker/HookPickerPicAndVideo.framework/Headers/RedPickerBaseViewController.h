//
//  RedPickerBaseViewController.h
//  SelectPhonesImageAndVideo
//
//  Created by huxinwen65 on 2017/5/18.
//  Copyright © 2017年 huxinwen65. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Photos/Photos.h>

#define RedAssetsPickerSelectedAssetsDidChangeNotification  @"RedAssetsPickerSelectedAssetsDidChangeNotification"
#define RedAssetsPickerDidSelectAssetNotification @"RedAssetsPickerDidSelectAssetNotification"
#define RedAssetsPickerDidDeselectAssetNotification @"RedAssetsPickerDidDeselectAssetNotification"

@protocol RedPickerViewControllerDelegate;

@interface RedPickerBaseViewController : UIViewController
@property (nonatomic, weak) id <RedPickerViewControllerDelegate> delegate;
/**设置默认进入的目录*/
@property (nonatomic, assign) PHAssetCollectionSubtype defaultAssetCollectionType;
/**设置需要显示目录数组*/
@property (nonatomic, copy) NSArray *assetCollectionSubtypes;
/**是否显示取消按钮*/
@property (nonatomic, assign) BOOL showsCancelButton;
/**是否显示空文件夹*/
@property (nonatomic, assign) BOOL showsEmptyAlbums;
/**支持最大选择数*/
@property (nonatomic, assign) NSUInteger maximumNumberOfSelection;

@property (nonatomic, strong) PHFetchOptions *assetsFetchOptions;

@property (nonatomic, strong) NSMutableArray *selectedAssets;
@property (nonatomic, strong) NSString* maxSelectedAlertStr;
/**
 *  Determines whether or not the done button is always enabled.
 *
 *  The done button is enabled only when assets are selected. To enable the done button even without assets selected,
 *  set this property’s value to `YES`.
 */
@property (nonatomic, assign) BOOL alwaysEnableDoneButton;

@property (nonatomic, readonly, strong) UISplitViewController *childSplitViewController;

@property (nonatomic, strong) PHFetchOptions *assetCollectionFetchOptions;

- (void)setShouldCollapseDetailViewController:(BOOL)collapse;
- (void)selectAsset:(PHAsset *)asset;
- (void)deselectAsset:(PHAsset *)asset;
- (void)finishPickingAssets:(id)sender;

@end

@protocol RedPickerViewControllerDelegate <NSObject>

- (void)assetsPickerController:(RedPickerBaseViewController *)picker didFinishPickingAssets:(NSArray *)assets;
@optional
- (void)assetsPickerControllerDidCancel:(RedPickerBaseViewController *)picker;

- (void)assetsPickerController:(RedPickerBaseViewController *)picker didSelectAsset:(PHAsset *)asset;

- (void)assetsPickerController:(RedPickerBaseViewController *)picker didDeselectAsset:(PHAsset *)asset;
- (BOOL)assetsPickerController:(RedPickerBaseViewController *)picker shouldEnableAsset:(PHAsset *)asset;
- (BOOL)assetsPickerController:(RedPickerBaseViewController *)picker shouldSelectAsset:(PHAsset *)asset;

- (BOOL)assetsPickerController:(RedPickerBaseViewController *)picker shouldDeselectAsset:(PHAsset *)asset;
@end
